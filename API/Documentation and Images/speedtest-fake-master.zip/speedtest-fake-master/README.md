# speedtest-fake
Generate real fake OOKLA Speedtest results with PHP very easily.   

## Dependencies
- cURL for PHP
- PHP 5.4+

### Demo
Live version can be found at https://jaydontaylor.com/speedtest.php
