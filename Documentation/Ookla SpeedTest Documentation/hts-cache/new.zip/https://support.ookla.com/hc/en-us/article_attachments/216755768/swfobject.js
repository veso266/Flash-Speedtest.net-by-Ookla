<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
  <meta charset="utf-8">
  <!-- v13473 -->
  <title>The page you were looking for doesn't exist &ndash; Ookla</title>

  <meta name="csrf-param" content="authenticity_token" />
<meta name="csrf-token" content="IkaqQepRdYuxOrKqe0axmGAlhrKQEOC4a/u9ginrcfXH80oLmdEqUzokk48WeQqdO9CZJ8xF9m15KMSOaIKrrQ==" />
  <meta name="robots" content="noindex, nofollow, noarchive, nosnippet" />

  <!-- Entypo pictograms by Daniel Bruce — www.entypo.com -->
  <link rel="stylesheet" media="all" href="//p13.zdassets.com/hc/assets/application-3b0b6df180f05e3fa954d2e4d90e4600.css" id="stylesheet" />
  <link rel="stylesheet" type="text/css" href="//p13.zdassets.com/hc/themes/129506/213867488/style-7e0d52207fcad1926c0e889e5c777db4.css?brand_id=3273006" />

  <link rel="shortcut icon" type="image/x-icon" href="//p13.zdassets.com/hc/settings_assets/129506/200332267/QivmyxkSUPNT3DWHleS9Ew-favicon.ico" />

  <!--[if lt IE 9]>
  <script>
    //Enable HTML5 elements for <IE9
    'abbr article aside audio bdi canvas data datalist details dialog \
    figcaption figure footer header hgroup main mark meter nav output \
    progress section summary template time video'.replace(/\w+/g,function(n){document.createElement(n)});
  </script>
<![endif]-->

  <script src="//p13.zdassets.com/hc/assets/jquery-b60ddb79ff2563b75442a6bac88b00b5.js"></script>
  
  
  

  <!-- add code here that should appear in the document head -->
<link rel="stylesheet" type="text/css" href="https://cloud.typography.com/7800252/7908972/css/fonts.css" />

  <script type="text/javascript" src="//p13.zdassets.com/hc/themes/129506/213867488/script-7e0d52207fcad1926c0e889e5c777db4.js?brand_id=3273006"></script>
</head>
<body class="">
  
  


  


  <div id="consent_blackbar"></div>
<header class="header">
  <div class="header-inner clearfix">
    <div class="logo"><a title="Home" href="/hc">
      <img src="//p13.zdassets.com/hc/settings_assets/129506/200332267/LG2vzklQtF3ViVrkVldoZw-speedtest-logo-white.svg" alt="Logo">
    </a></div>
    <nav class="user-nav">
      
      <a class="submit-a-request" href="https://www.ookla.com/support-form">Submit a request</a>
        <a class="login" data-auth-action="signin" role="button" href="/hc/signin?return_to=https%3A%2F%2Fsupport.ookla.com%2Fhc%2Fen-us%2Farticle_attachments%2F216755768%2Fswfobject.js&amp;locale=1">Sign in</a>

    </nav>
  </div>
</header>

<div class="search-unit">
  <form role="search" class="search" data-search="" action="/hc/en-us/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" /><input type="search" name="query" id="query" placeholder="Search" aria-label="Search" />
<input type="submit" name="commit" value="Search" /></form>
</div>


  <main role="main">
    <div class="error-page">
  <h1>oops</h1>

  

  

  
    <h2>The page you were looking for doesn't exist</h2>
    <p>You may have mistyped the address or the page may have moved</p>
  

  <a title="Home" href="/hc">
    Take me back to the home page
  </a>
</div>

  </main>

  <footer class="footer">
  <!-- Footer content -->
  <div class="footer-inner">
	  <div id="teconsent" style="display: none;"></div>
  	<script async="async" src="//consent.truste.com/notice?domain=ziffdavis.com&c=teconsent&js=bb&noticeType=bb" crossorigin=""></script>
  </div>
</footer>



  <!-- / -->

  <script type="text/javascript" src="//p13.zdassets.com/hc/assets/locales/en-us-81bc1ea51b70d411a7857e0f6f67df60.js"></script>
  <script src="https://ookla.zendesk.com/auth/v2/host.js" data-brand-id="3273006" data-return-to="https://support.ookla.com/hc/en-us/article_attachments/216755768/swfobject.js" data-theme="hc" data-locale="1" data-auth-origin="3273006,true,true"></script>
  <script type="text/javascript" src="https://p13.zdassets.com/assets/zendesk_pci_hc.v4.js"></script>

  <script type="text/javascript">
  /*

    Greetings sourcecode lurker!

    This is for internal Zendesk and legacy usage,
    we don't support or guarantee any of these values
    so please don't build stuff on top of them.

  */

  HelpCenter = {};
  HelpCenter.account = {"subdomain":"ookla","environment":"production","name":"Ookla"};
  HelpCenter.user = {"identifier":"da39a3ee5e6b4b0d3255bfef95601890afd80709","email":null,"name":null,"role":"anonymous","avatar_url":"https://assets.zendesk.com/hc/assets/default_avatar.png","organizations":[],"groups":[]};
  HelpCenter.internal = {"asset_url":"//p13.zdassets.com/hc/assets/","current_session":{"locale":"en-us","csrf_token":"oppJ26KbUgASeJHpuQaLk45c0fGdIIl1RKEOp4PGimFHL6mR0RsN2JlmsMzUOTCW1anOZMF1n6BWcnerwq9QOQ==","shared_csrf_token":null},"settings":{"zopim_enabled":false,"spam_filter_enabled":true},"current_record_id":null,"current_record_url":null,"current_record_title":null,"search_results_count":null,"current_text_direction":"ltr","current_brand_url":"https://ookla.zendesk.com","current_host_mapping":"support.ookla.com","current_path":null,"authentication_domain":"https://ookla.zendesk.com","show_autocomplete_breadcrumbs":true,"user_info_changing_enabled":false,"has_user_profiles_enabled":true,"has_anonymous_kb_voting":false,"has_advanced_upsell":false,"has_multi_language_help_center":true,"mobile_device":false,"mobile_site_enabled":true,"show_at_mentions":false,"has_copied_content":true,"embeddables_config":{"embeddables_web_widget":false,"embeddables_automatic_answers":false,"embeddables_connect_ipms":false},"embeddables_domain":"zendesk.com","answer_bot_subdomain":"static","plans_url":"https://support.ookla.com/hc/admin/plan","manage_content_url":"https://support.ookla.com/hc","arrange_content_url":"https://support.ookla.com/hc/admin/arrange_contents","general_settings_url":"https://support.ookla.com/hc/admin/general_settings","user_segments_url":"https://support.ookla.com/hc/admin/user_segments","import_articles_url":"https://support.ookla.com/hc/admin/import_articles","has_community_enabled":false,"has_multiselect_field":true,"has_groups":true,"has_internal_sections":true,"has_organizations":true,"has_tag_restrictions":true,"has_answer_bot_web_form_enabled":false,"has_answer_bot_embeddable_standalone":true,"billing_url":"/access/return_to?return_to=https://ookla.zendesk.com/billing","has_answer_bot":true,"has_guide_docs_importer":false,"answer_bot_management_url":"https://support.ookla.com/hc/admin/answer_bot","is_account_owner":false,"has_theming_templates":false,"theming_center_url":"https://support.ookla.com/theming","theming_cookie_key":"hc-da39a3ee5e6b4b0d3255bfef95601890afd80709-preview","is_preview":false};
</script>

  <script src="//p13.zdassets.com/hc/assets/hc_enduser-99ecbf6c6034819f1a2d9f538431319f.js"></script>
  

  <script type="text/javascript">
    (function() {
  var Tracker = {};

  Tracker.track = function(eventName, data) {
    var url = "https://support.ookla.com/hc/tracking/events";

    var payload = {
      "event": eventName,
      "data": data,
      "referrer": document.referrer
    };

    var xhr = new XMLHttpRequest();

    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/json; charset=UTF-8");
    xhr.send(JSON.stringify(payload));
  };

})();

  </script>
</body>
</html>