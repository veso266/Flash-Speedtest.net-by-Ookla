
Requirements: (these must be completed before using this AIR project!)

	- Flex Builder 3
	- ModestMaps as3/lib checkedout in its own Flex Library Project named "ModestMap"
		- Checkout the as3/lib folder into your Flex builder workspace. 
		- Create a new Flex Library Project named "ModestMap" that uses the SVN check out folder.


